package com.cotizapack.cotizaweb.cotizaweb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
