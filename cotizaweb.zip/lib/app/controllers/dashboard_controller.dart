import 'package:cotizaweb/app/controllers/global_Controller.dart';
import 'package:get/get.dart';

class DashboardController extends GetxController {
  final GlobalController globalController = Get.find<GlobalController>();

  @override
  void onInit() {
    super.onInit();
  }
}
