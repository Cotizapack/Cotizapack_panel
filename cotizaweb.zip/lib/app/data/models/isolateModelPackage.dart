import 'PackageModel.dart';

class IsolateparamPackage {
  final Packageclass? package;
  final List<int>? image;
  final String? filename;

  IsolateparamPackage({this.package, this.image, this.filename});
}
