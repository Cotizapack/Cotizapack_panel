import 'package:cotizaweb/app/data/models/banner_model.dart';

class Isolateparam {
  final BannerModel? banner;
  final List<int>? image;
  final String? filename;

  Isolateparam({this.banner, this.image, this.filename});
}
