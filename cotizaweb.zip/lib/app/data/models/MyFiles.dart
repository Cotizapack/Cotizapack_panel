import 'package:flutter/material.dart';

class ClouddataInfo {
  String? title;
  int? numOfFiels;
  Color? color;

  ClouddataInfo({this.title, this.numOfFiels, this.color});
}
