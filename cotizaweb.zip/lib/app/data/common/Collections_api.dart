abstract class Collections {
  static const USER = '613053a139dbb';
  static const CATEGORYUSER = '612d3e14cc481';
  static const CUSTOMERS = '612d4505a8809';
  static const CATEGORYPRODUCTS = '612d46fee2971';
  static const PRODUCTS_SERVICES = '612d4590e5ed6';
  static const QUOTATIONS = '612d769fecf47';
  static const STATISTIC = '612d469aef3cd';
  static const PACKAGE = '612ef56b00177';
  static const MYPACKAGE = '612d46c6f133a';
  static const BANNERS = '612d4545bc0e6';
  static const BUYPACKAGE = '612d46c6f133a';

  ///Id del Equipo de administradores en la base de datos
  static const TEAMADMINID = '612d354b900e9';
}
